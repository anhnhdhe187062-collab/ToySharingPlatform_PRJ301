

<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-3 mb-4">
            <div class="card shadow-sm border-0 rounded-4 overflow-hidden">
                <div class="card-header bg-primary text-white py-3">
                    <h5 class="mb-0">Trang cá nhân</h5>
                </div>
                <div class="list-group list-group-flush">
                    <a href="profile.jsp" class="list-group-item list-group-item-action active py-3">
                        <i class="fa fa-user-circle me-2"></i> Thông tin tài khoản
                    </a>
                    <a href="history.jsp" class="list-group-item list-group-item-action py-3">
                        <i class="fa fa-history me-2"></i> Lịch sử mượn đồ
                    </a>
                    <a href="logout" class="list-group-item list-group-item-action py-3 text-danger">
                        <i class="fa fa-sign-out-alt me-2"></i> Đăng xuất
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-9">
            <div class="card shadow-sm border-0 rounded-4 p-4">
                <h3 class="fw-bold text-primary mb-4">Cập nhật thông tin</h3>
                
                <%-- Hiển thị thông báo nếu có --%>
                <c:if test="${not empty requestScope.MESSAGE}">
                    <div class="alert alert-success">${requestScope.MESSAGE}</div>
                </c:if>
                <c:if test="${not empty requestScope.ERROR}">
                    <div class="alert alert-danger">${requestScope.ERROR}</div>
                </c:if>

                <form action="${pageContext.request.contextPath}/update" method="POST">
                    <div class="mb-3">
                        <label class="form-label text-muted">Tên đăng nhập (ID)</label>
                        <input type="text" name="userID" value="${sessionScope.LOGIN_USER.userID}" class="form-control bg-light" readonly>
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-muted">Họ và tên</label>
                        <input type="text" name="fullName" value="${sessionScope.LOGIN_USER.fullName}" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-muted">Email</label>
                        <input type="email" name="email" value="${sessionScope.LOGIN_USER.email}" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-muted">Số điện thoại</label>
                        <input type="text" name="phone" value="${sessionScope.LOGIN_USER.phone}" class="form-control" placeholder="Nhập số điện thoại...">
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-muted">Địa chỉ</label>
                        <textarea name="address" class="form-control" rows="3" placeholder="Nhập địa chỉ của bạn...">${sessionScope.LOGIN_USER.address}</textarea>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary px-5 rounded-pill">Lưu thay đổi</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>