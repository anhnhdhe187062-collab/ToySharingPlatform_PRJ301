
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<footer class="bg-light text-center text-lg-start mt-5 py-3 border-top">
    <div class="text-center p-3 text-muted">
        © 2026 ToyShare Project - Môn PRJ301
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>