

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<nav class="navbar navbar-expand-lg navbar-dark shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="HomeController">🧸 ToyShare</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="HomeController">Trang chủ</a></li>
                <li class="nav-item"><a class="nav-link" href="RequestServlet?action=History">Lịch sử mượn</a></li>
            </ul>
            <ul class="navbar-nav ms-auto">
                <c:choose>
                    <c:when test="${empty sessionScope.LOGIN_USER}">
                        <li class="nav-item"><a class="nav-link btn btn-light text-primary btn-sm px-3 rounded-pill" href="login.jsp">Đăng nhập</a></li>
                        </c:when>
                        <c:otherwise>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white fw-bold" href="#" data-bs-toggle="dropdown">
                                <i class="fa fa-user-circle"></i> ${sessionScope.LOGIN_USER.fullName}
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end shadow border-0 rounded-3">
                                <li><a class="dropdown-item py-2" href="profile.jsp"><i class="fa fa-user me-2"></i> Tài khoản</a></li>
                                <li><a class="dropdown-item py-2" href="RequestServlet?action=History"><i class="fa fa-history me-2"></i> Lịch sử mượn</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item py-2 text-danger" href="logout"><i class="fa fa-sign-out-alt me-2"></i> Đăng xuất</a></li>
                            </ul>
                        </li>
                    </c:otherwise>
                </c:choose>
            </ul>
        </div>
    </div>
</nav>
