

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<div class="row mb-5">
    <div class="col-12 text-center">
        <h1 class="display-4 fw-bold text-primary mb-3">Thế giới đồ chơi</h1>
        <p class="text-muted">Chọn một món đồ chơi yêu thích và bắt đầu hành trình sẻ chia.</p>
    </div>
</div>

<div class="row">
    <%-- Ví dụ dữ liệu giả --%>
    <c:forEach var="i" begin="1" end="6">
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card toy-card h-100">
                <img src="https://via.placeholder.com/400x300?text=Toy+Image" class="toy-img" alt="Toy">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="status-badge bg-success text-white">Sẵn sàng</span>
                        <span class="text-primary fw-bold">Miễn phí</span>
                    </div>
                    <h5 class="card-title fw-bold">Tên đồ chơi #${i}</h5>
                    <p class="card-text text-muted small">Mô tả ngắn gọn về tình trạng và loại đồ chơi của bé...</p>
                    <a href="RequestServlet?action=ViewDetail&id=${i}" class="btn btn-grad w-100 mt-2">Xem chi tiết & Mượn</a>
                </div>
            </div>
        </div>
    </c:forEach>
</div>