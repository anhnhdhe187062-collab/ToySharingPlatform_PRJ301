<%-- 
    Document   : index
    Created on : Apr 22, 2026, 9:36:27 PM
    Author     : nguye
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<jsp:forward page="layout/main_layout.jsp">
    <jsp:param name="title" value="ToyShare - Trang chủ" />
    <jsp:param name="contentPage" value="../home.jsp" />
</jsp:forward>
