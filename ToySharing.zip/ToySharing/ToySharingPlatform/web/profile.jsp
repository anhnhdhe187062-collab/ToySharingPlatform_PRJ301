<%-- 
    Document   : profile
    Created on : Apr 19, 2026, 5:09:55 PM
    Author     : ADMIN
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<jsp:forward page="layout/main_layout.jsp">
    <jsp:param name="title" value="Tài khoản của tôi - ToyShare" />
    <jsp:param name="contentPage" value="../profile_content.jsp" />
</jsp:forward>