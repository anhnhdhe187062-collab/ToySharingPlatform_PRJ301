package dao;

import DBcontext.DBContext;
import Model.UserDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {

public UserDTO checkLogin(String user, String pass) {
    String sql = "SELECT userID, password, fullName, email, phone, address, roleID, status FROM Users WHERE userID=? AND password=?";
    try (Connection conn = new DBContext().getConnection(); 
         PreparedStatement ps = conn.prepareStatement(sql)) {
        
        ps.setString(1, user);
        ps.setString(2, pass);
        
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                String userID = rs.getString("userID");
                String fullName = rs.getString("fullName");
                String email = rs.getString("email");
                String phone = rs.getString("phone");
                String address = rs.getString("address");
                int roleID = rs.getInt("roleID");
                boolean status = rs.getBoolean("status");

                return new UserDTO(userID, "", fullName, email, phone, address, roleID, status);
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return null;
}

    // Hàm đăng ký người dùng mới
    public boolean registerUser(String id, String pass, String name, String email) {
        String sql = "INSERT INTO Users(userID, password, fullName, email, roleID) VALUES(?,?,?,?,2)";
        try (Connection conn = new DBContext().getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            ps.setString(2, pass);
            ps.setString(3, name);
            ps.setString(4, email);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updatePassword(String userID, String email, String newPassword) {
        // Bước 1: Kiểm tra xem cặp userID và email có tồn tại trong hệ thống không
        String checkSql = "SELECT userID FROM Users WHERE userID = ? AND email = ?";
        String updateSql = "UPDATE Users SET password = ? WHERE userID = ? AND email = ?";

        try (Connection conn = new DBContext().getConnection()) {
            // Kiểm tra sự tồn tại
            try (PreparedStatement psCheck = conn.prepareStatement(checkSql)) {
                psCheck.setString(1, userID);
                psCheck.setString(2, email);
                try (ResultSet rs = psCheck.executeQuery()) {
                    if (rs.next()) {
                        // Bước 2: Nếu tồn tại, tiến hành update
                        try (PreparedStatement psUpdate = conn.prepareStatement(updateSql)) {
                            psUpdate.setString(1, newPassword);
                            psUpdate.setString(2, userID);
                            psUpdate.setString(3, email);
                            return psUpdate.executeUpdate() > 0;
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateProfile(UserDTO user) {
        String sql = "UPDATE Users SET fullName = ?, email = ?, phone = ?, address = ? WHERE userID = ?";
        try {
            Connection conn = new DBContext().getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setNString(1, user.getFullName()); // Dùng setNString để tránh lỗi font tiếng Việt
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPhone());
            ps.setNString(4, user.getAddress());
            ps.setString(5, user.getUserID());

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
